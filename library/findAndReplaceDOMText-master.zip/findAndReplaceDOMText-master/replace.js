findAndReplaceDOMText(document.body, {
  find: 'a',
  wrap: 'em',
  wrapClass:'letter-a',
});

findAndReplaceDOMText(document.body, {
  find: 'b',
  wrap: 'em',
  wrapClass:'letter-b',
});

findAndReplaceDOMText(document.body, {
  find: 'c',
  wrap: 'em',
  wrapClass:'letter-c',
});
findAndReplaceDOMText(document.body, {
  find: 'd',
  wrap: 'em',
  wrapClass:'letter-d',
});
findAndReplaceDOMText(document.body, {
  find: 'e',
  wrap: 'em',
  wrapClass:'letter-e',
});
findAndReplaceDOMText(document.body, {
  find: 'f',
  wrap: 'em',
  wrapClass:'letter-f',
});
findAndReplaceDOMText(document.body, {
  find: 'g',
  wrap: 'em',
  wrapClass:'letter-g',
});
findAndReplaceDOMText(document.body, {
  find: 'h',
  wrap: 'em',
  wrapClass:'letter-h',
});
findAndReplaceDOMText(document.body, {
  find: 'i',
  wrap: 'em',
  wrapClass:'letter-i',
});
findAndReplaceDOMText(document.body, {
  find: 'j',
  wrap: 'em',
  wrapClass:'letter-k',
});
findAndReplaceDOMText(document.body, {
  find: 'k',
  wrap: 'em',
  wrapClass:'letter-k',
});
findAndReplaceDOMText(document.body, {
  find: 'l',
  wrap: 'em',
  wrapClass:'letter-l',
});
findAndReplaceDOMText(document.body, {
  find: 'm',
  wrap: 'em',
  wrapClass:'letter-m',
});
findAndReplaceDOMText(document.body, {
  find: 'n',
  wrap: 'em',
  wrapClass:'letter-n',
});


findAndReplaceDOMText(document.body, {
  find: 'o',
  wrap: 'em',
  wrapClass:'letter-o',
});

findAndReplaceDOMText(document.body, {
  find: 'p',
  wrap: 'em',
  wrapClass:'letter-p',
});

findAndReplaceDOMText(document.body, {
  find: 'q',
  wrap: 'em',
  wrapClass:'letter-q',
});

findAndReplaceDOMText(document.body, {
  find: 'r',
  wrap: 'em',
  wrapClass:'letter-r',
});

findAndReplaceDOMText(document.body, {
  find: 's',
  wrap: 'em',
  wrapClass:'letter-s',
});
findAndReplaceDOMText(document.body, {
  find: 't',
  wrap: 'em',
  wrapClass:'letter-t',
});
findAndReplaceDOMText(document.body, {
  find: 'u',
  wrap: 'em',
  wrapClass:'letter-u',
});

findAndReplaceDOMText(document.body, {
  find: 'v',
  wrap: 'em',
  wrapClass:'letter-v',
});

findAndReplaceDOMText(document.body, {
  find: 'w',
  wrap: 'em',
  wrapClass:'letter-w',
});

findAndReplaceDOMText(document.body, {
  find: 'x',
  wrap: 'em',
  wrapClass:'letter-x',
});

findAndReplaceDOMText(document.body, {
  find: 'y',
  wrap: 'em',
  wrapClass:'letter-y',
});

findAndReplaceDOMText(document.body, {
  find: 'z',
  wrap: 'em',
  wrapClass:'letter-z',
});
